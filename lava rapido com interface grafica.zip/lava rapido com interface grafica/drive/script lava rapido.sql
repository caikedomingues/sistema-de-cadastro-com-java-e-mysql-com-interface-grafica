
create database lavarapido;

create table clientes(

nome varchar(30) not null,
cpf varchar(6) not null unique,
anoNasc varchar(4) not null,
email text,
telefone varchar(11),

primary key(cpf)

)default charset = utf8;

select * from clientes;

create table funcionarios(

nome varchar(30),
id int auto_increment unique,
funcao text not null,
setor text not null, 
salario int not null,

primary key(id)

) default charset = utf8;

select * from funcionarios;

create table veiculos(

idveiculo int auto_increment unique,
modelo text not null,
cor text not null,
placa varchar(4) not null unique,
servico text not null,
primary key(placa)


)default charset = utf8;

alter table veiculosveiculos
add column servico text not null;

select * from veiculos;

