import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CadastroFuncionario {

	JFrame frame;
	private JTextField txtnome;
	private JTextField txtfuncao;
	private JTextField txtsetor;
	private JTextField txtsalario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroFuncionario window = new CadastroFuncionario();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CadastroFuncionario() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 810, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Cadastro de Funcionários");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(280, 45, 231, 25);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblnome = new JLabel("Nome:");
		lblnome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnome.setBounds(99, 103, 72, 13);
		frame.getContentPane().add(lblnome);
		
		txtnome = new JTextField();
		txtnome.setBounds(168, 103, 188, 19);
		frame.getContentPane().add(txtnome);
		txtnome.setColumns(10);
		
		JLabel lblfuncao = new JLabel("Função:");
		lblfuncao.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblfuncao.setBounds(99, 150, 72, 35);
		frame.getContentPane().add(lblfuncao);
		
		txtfuncao = new JTextField();
		txtfuncao.setColumns(10);
		txtfuncao.setBounds(168, 156, 188, 19);
		frame.getContentPane().add(txtfuncao);
		
		JLabel lblsetor = new JLabel("Setor:");
		lblsetor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblsetor.setBounds(99, 202, 72, 35);
		frame.getContentPane().add(lblsetor);
		
		txtsetor = new JTextField();
		txtsetor.setColumns(10);
		txtsetor.setBounds(168, 213, 188, 19);
		frame.getContentPane().add(txtsetor);
		
		JLabel lblsalario = new JLabel("Salario:");
		lblsalario.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblsalario.setBounds(99, 247, 72, 35);
		frame.getContentPane().add(lblsalario);
		
		txtsalario = new JTextField();
		txtsalario.setColumns(10);
		txtsalario.setBounds(168, 258, 188, 19);
		frame.getContentPane().add(txtsalario);
		
		JButton btncadastro = new JButton("Cadastrar");
		btncadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int salario = Integer.parseInt(txtsalario.getText());
				
				ConexaoBanco banco = new ConexaoBanco();
				
				banco.conexao();
				banco.cadastrarFuncionario(txtnome.getText(), txtfuncao.getText(), txtsetor.getText(), salario);
				banco.desconectar();
				
			}
		});
		btncadastro.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btncadastro.setBounds(271, 315, 132, 44);
		frame.getContentPane().add(btncadastro);
		
		JButton btnvoltar = new JButton("Voltar a funcionarios");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaFuncionario window = new TelaFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(33, 315, 209, 44);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnome.setText("");
				txtfuncao.setText("");
				txtsetor.setText("");
				txtsalario.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(431, 315, 132, 44);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(585, 315, 165, 44);
		frame.getContentPane().add(btnmenu);
	}
}
