import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaVeiculos {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaVeiculos window = new TelaVeiculos();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaVeiculos() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 928, 576);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btncadastrar = new JButton("Cadastre um veiculo");
		btncadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CadastroVeiculo window = new CadastroVeiculo();
				
				window.frame.setVisible(true);
			}
		});
		btncadastrar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btncadastrar.setBounds(292, 91, 257, 55);
		frame.getContentPane().add(btncadastrar);
		
		JButton btnpesquisar = new JButton("pesquise um veiculo");
		btnpesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PesquisarVeiculo window = new  PesquisarVeiculo();
				
				window.frame.setVisible(true);
			}
		});
		btnpesquisar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnpesquisar.setBounds(292, 178, 257, 55);
		frame.getContentPane().add(btnpesquisar);
		
		JButton btnalterar = new JButton("alterar um veiculo");
		btnalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AlterarVeiculo window = new AlterarVeiculo();
				
				window.frame.setVisible(true);
				
			}
		});
		btnalterar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnalterar.setBounds(292, 267, 257, 55);
		frame.getContentPane().add(btnalterar);
		
		JButton btnapagar = new JButton("apague um veiculo");
		btnapagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ApagarVeiculo window = new ApagarVeiculo();
				
				window.frame.setVisible(true);
			}
		});
		btnapagar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnapagar.setBounds(292, 353, 257, 55);
		frame.getContentPane().add(btnapagar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(308, 438, 213, 52);
		frame.getContentPane().add(btnmenu);
	}

}
