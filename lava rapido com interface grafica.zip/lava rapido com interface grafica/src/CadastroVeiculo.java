import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CadastroVeiculo {

	JFrame frame;
	private JTextField txtmodelo;
	private JTextField txtcor;
	private JTextField txtplaca;
	private JTextField txtservico;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroVeiculo window = new CadastroVeiculo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CadastroVeiculo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 812, 438);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Cadastro de Veiculos");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(232, 37, 204, 35);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblmodelo = new JLabel("Modelo: ");
		lblmodelo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblmodelo.setBounds(96, 100, 102, 22);
		frame.getContentPane().add(lblmodelo);
		
		txtmodelo = new JTextField();
		txtmodelo.setBounds(168, 105, 165, 19);
		frame.getContentPane().add(txtmodelo);
		txtmodelo.setColumns(10);
		
		JLabel lblcor = new JLabel("Cor:");
		lblcor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblcor.setBounds(96, 146, 102, 22);
		frame.getContentPane().add(lblcor);
		
		txtcor = new JTextField();
		txtcor.setColumns(10);
		txtcor.setBounds(168, 151, 165, 19);
		frame.getContentPane().add(txtcor);
		
		JLabel lblplaca = new JLabel("Placa:");
		lblplaca.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblplaca.setBounds(96, 194, 102, 22);
		frame.getContentPane().add(lblplaca);
		
		txtplaca = new JTextField();
		txtplaca.setColumns(10);
		txtplaca.setBounds(168, 199, 165, 19);
		frame.getContentPane().add(txtplaca);
		
		JLabel lblservico = new JLabel("Serviço:");
		lblservico.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblservico.setBounds(96, 237, 102, 22);
		frame.getContentPane().add(lblservico);
		
		txtservico = new JTextField();
		txtservico.setColumns(10);
		txtservico.setBounds(168, 242, 165, 19);
		frame.getContentPane().add(txtservico);
		
		JButton btncadastrar = new JButton("Cadastrar");
		btncadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexaoBanco banco = new ConexaoBanco();
				
				if(txtplaca.getText().length() > 4 || txtplaca.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A placa deve conter apenas 4 digitos");
				}
				
				banco.conexao();
				banco.cadastrarVeiculo(txtmodelo.getText(), txtcor.getText(), txtplaca.getText(), txtservico.getText());
				banco.desconectar();
			}
		});
		btncadastrar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btncadastrar.setBounds(249, 315, 127, 40);
		frame.getContentPane().add(btncadastrar);
		
		JButton btnvoltar = new JButton("Voltar a Veiculos");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaVeiculos window = new TelaVeiculos();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(31, 315, 183, 40);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtmodelo.setText("");
				txtcor.setText("");
				txtplaca.setText("");
				txtservico.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(407, 315, 127, 40);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(565, 315, 165, 40);
		frame.getContentPane().add(btnmenu);
	}

}
