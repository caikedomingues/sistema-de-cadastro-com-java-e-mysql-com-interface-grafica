import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class TelaFuncionario {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaFuncionario window = new TelaFuncionario();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaFuncionario() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 760, 589);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btncadastro = new JButton("cadastre um funcionário");
		btncadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CadastroFuncionario window = new CadastroFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		btncadastro.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btncadastro.setBounds(237, 111, 264, 62);
		frame.getContentPane().add(btncadastro);
		
		JButton btnpesquisar = new JButton("pesquise um funcionário");
		btnpesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PesquisarFuncionario window = new PesquisarFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		btnpesquisar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnpesquisar.setBounds(237, 203, 264, 62);
		frame.getContentPane().add(btnpesquisar);
		
		JButton btnalterar = new JButton("altere os dados do funcionario");
		btnalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AlterarFuncionario window = new AlterarFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		btnalterar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnalterar.setBounds(229, 304, 287, 62);
		frame.getContentPane().add(btnalterar);
		
		JButton btnapagar = new JButton("apague um funcionário");
		btnapagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ApagarFuncionario window = new ApagarFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		btnapagar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnapagar.setBounds(237, 390, 264, 62);
		frame.getContentPane().add(btnapagar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(252, 479, 213, 52);
		frame.getContentPane().add(btnmenu);
	}
}
