import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
public class ApagarCliente {

	JFrame frame;
	private JTextField txtcpf;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApagarCliente window = new ApagarCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ApagarCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 762, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Informe o cpf do cliente que será excluido");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(83, 25, 406, 25);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblcpf = new JLabel("CPF:");
		lblcpf.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblcpf.setBounds(93, 92, 45, 13);
		frame.getContentPane().add(lblcpf);
		
		txtcpf = new JTextField();
		txtcpf.setBounds(147, 92, 128, 19);
		frame.getContentPane().add(txtcpf);
		txtcpf.setColumns(10);
		
		JButton btnapagar = new JButton("Apagar Cliente");
		btnapagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexaoBanco banco = new ConexaoBanco();
				
				if(txtcpf.getText().length() > 6 || txtcpf.getText().length() < 6) {
					
					JOptionPane.showMessageDialog(null, "O cpf deve conter apenas 6 digitos");
				}
				
				banco.conexao();
				banco.apagarCliente(txtcpf.getText());
				banco.desconectar();
			}
		});
		btnapagar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnapagar.setBounds(197, 156, 141, 37);
		frame.getContentPane().add(btnapagar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtcpf.setText("");
			}
		});
		btnLimpar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnLimpar.setBounds(363, 156, 141, 37);
		frame.getContentPane().add(btnLimpar);
		
		JButton btnvoltar = new JButton("voltar a clientes");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaCliente window = new TelaCliente();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnvoltar.setBounds(30, 156, 141, 37);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnmenu.setBounds(530, 156, 141, 37);
		frame.getContentPane().add(btnmenu);
	}

}
