import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AlterarFuncionario {

	JFrame frame;
	private JTextField txtid;
	private JTextField txtnome;
	private JTextField txtfuncao;
	private JTextField txtsetor;
	private JTextField txtsalario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AlterarFuncionario window = new AlterarFuncionario();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AlterarFuncionario() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 819, 485);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Informe o id do funcionario que terá os dados alterados");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(155, 42, 514, 40);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblid = new JLabel("ID:");
		lblid.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblid.setBounds(92, 112, 45, 13);
		frame.getContentPane().add(lblid);
		
		txtid = new JTextField();
		txtid.setBounds(142, 112, 197, 19);
		frame.getContentPane().add(txtid);
		txtid.setColumns(10);
		
		JLabel blnome = new JLabel("Nome:");
		blnome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		blnome.setBounds(78, 160, 60, 13);
		frame.getContentPane().add(blnome);
		
		txtnome = new JTextField();
		txtnome.setColumns(10);
		txtnome.setBounds(142, 160, 197, 19);
		frame.getContentPane().add(txtnome);
		
		JLabel lblfuncao = new JLabel("Função:");
		lblfuncao.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblfuncao.setBounds(72, 199, 78, 22);
		frame.getContentPane().add(lblfuncao);
		
		txtfuncao = new JTextField();
		txtfuncao.setColumns(10);
		txtfuncao.setBounds(142, 204, 197, 19);
		frame.getContentPane().add(txtfuncao);
		
		JLabel lblsetor = new JLabel("Setor:");
		lblsetor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblsetor.setBounds(72, 242, 78, 22);
		frame.getContentPane().add(lblsetor);
		
		txtsetor = new JTextField();
		txtsetor.setColumns(10);
		txtsetor.setBounds(142, 247, 197, 19);
		frame.getContentPane().add(txtsetor);
		
		JLabel lblsalario = new JLabel("Salario:");
		lblsalario.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblsalario.setBounds(72, 279, 78, 22);
		frame.getContentPane().add(lblsalario);
		
		txtsalario = new JTextField();
		txtsalario.setColumns(10);
		txtsalario.setBounds(142, 284, 197, 19);
		frame.getContentPane().add(txtsalario);
		
		JButton lblalterar = new JButton("Alterar");
		lblalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int id = Integer.parseInt(txtid.getText());
				
				int salario = Integer.parseInt(txtsalario.getText());
				
				ConexaoBanco banco = new ConexaoBanco();
				
				banco.conexao();
				banco.alterarFuncionario(id, txtnome.getText(), txtfuncao.getText(), txtsetor.getText(), salario);
				banco.desconectar();
			}
		});
		lblalterar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblalterar.setBounds(266, 343, 108, 40);
		frame.getContentPane().add(lblalterar);
		
		JButton lblvoltar = new JButton("Voltar a Funcionários");
		lblvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaFuncionario window = new TelaFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		lblvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblvoltar.setBounds(21, 343, 209, 40);
		frame.getContentPane().add(lblvoltar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtid.setText("");
				txtnome.setText("");
				txtfuncao.setText("");
				txtsetor.setText("");
				txtsalario.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(405, 343, 108, 40);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(547, 343, 158, 40);
		frame.getContentPane().add(btnmenu);
	}

}
