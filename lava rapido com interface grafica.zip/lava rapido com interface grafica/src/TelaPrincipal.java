import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPrincipal {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal window = new TelaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 857, 554);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnClientes = new JButton("Clientes");
		btnClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaCliente window = new TelaCliente();
				
				window.frame.setVisible(true);
			}
		});
		btnClientes.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnClientes.setBounds(279, 118, 145, 52);
		frame.getContentPane().add(btnClientes);
		
		JLabel lbltitulo = new JLabel("Bem vindo ao sistema");
		lbltitulo.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lbltitulo.setBounds(242, 35, 206, 36);
		frame.getContentPane().add(lbltitulo);
		
		JButton btnFuncionarios = new JButton("Funcionarios");
		btnFuncionarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaFuncionario window = new TelaFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		btnFuncionarios.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnFuncionarios.setBounds(279, 196, 145, 52);
		frame.getContentPane().add(btnFuncionarios);
		
		JButton btnVeiculos = new JButton("Veiculos");
		btnVeiculos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaVeiculos window = new TelaVeiculos();
				
				window.frame.setVisible(true);
			}
		});
		btnVeiculos.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnVeiculos.setBounds(279, 270, 145, 52);
		frame.getContentPane().add(btnVeiculos);
		
		JButton btnsair = new JButton("Sair");
		btnsair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnsair.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnsair.setBounds(279, 345, 145, 52);
		frame.getContentPane().add(btnsair);
	}
}
