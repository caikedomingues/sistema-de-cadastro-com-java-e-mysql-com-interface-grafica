import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CadastroCliente {

	JFrame frame;
	private final JLabel lblNome = new JLabel("Nome:");
	private JTextField txtnome;
	private JLabel lblcpf;
	private JTextField txtcpf;
	private JLabel lblnascimento;
	private JTextField txtano;
	private JLabel lblemail;
	private JTextField txtemail;
	private JLabel lbltelefone;
	private JTextField txttelefone;
	private final JLabel bltitulo = new JLabel("Cadastro de clientes");
	private JButton btncadastro;
	private JButton btnLimpar;
	private JButton btnvoltar;
	private JButton btnmenu;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroCliente window = new CadastroCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CadastroCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 699, 495);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNome.setBounds(60, 64, 126, 36);
		frame.getContentPane().add(lblNome);
		
		txtnome = new JTextField();
		txtnome.setBounds(165, 76, 182, 19);
		frame.getContentPane().add(txtnome);
		txtnome.setColumns(10);
		
		lblcpf = new JLabel("CPF:");
		lblcpf.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblcpf.setBounds(60, 110, 126, 36);
		frame.getContentPane().add(lblcpf);
		
		txtcpf = new JTextField();
		txtcpf.setColumns(10);
		txtcpf.setBounds(165, 122, 182, 19);
		frame.getContentPane().add(txtcpf);
		
		lblnascimento = new JLabel("Ano de nascimento:");
		lblnascimento.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblnascimento.setBounds(10, 157, 166, 36);
		frame.getContentPane().add(lblnascimento);
		
		txtano = new JTextField();
		txtano.setColumns(10);
		txtano.setBounds(165, 169, 182, 19);
		frame.getContentPane().add(txtano);
		
		lblemail = new JLabel("Email:");
		lblemail.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblemail.setBounds(60, 203, 166, 36);
		frame.getContentPane().add(lblemail);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBounds(165, 215, 182, 19);
		frame.getContentPane().add(txtemail);
		
		lbltelefone = new JLabel("Telefone:");
		lbltelefone.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lbltelefone.setBounds(60, 249, 166, 36);
		frame.getContentPane().add(lbltelefone);
		
		txttelefone = new JTextField();
		txttelefone.setColumns(10);
		txttelefone.setBounds(165, 261, 182, 19);
		frame.getContentPane().add(txttelefone);
		bltitulo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		bltitulo.setBounds(204, 10, 200, 36);
		frame.getContentPane().add(bltitulo);
		
		btncadastro = new JButton("Cadastrar");
		btncadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexaoBanco banco = new ConexaoBanco();
				
				if(txtcpf.getText().length() > 6 || txtcpf.getText().length() < 6) {
					
					JOptionPane.showMessageDialog(null, "O cpf deve conter apenas 6 digitos");
				}
				
				if(txttelefone.getText().length() < 11 || txttelefone.getText().length() > 11) {
					
					JOptionPane.showMessageDialog(null, " O telefone deve conter apenas 11 digitos");
				}
				
				banco.conexao();
				banco.inserirCliente(txtnome.getText(), txtcpf.getText(), txtano.getText(), txtemail.getText(), txttelefone.getText());
				banco.desconectar();
				
			}
		});
		btncadastro.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btncadastro.setBounds(204, 316, 112, 46);
		frame.getContentPane().add(btncadastro);
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnome.setText("");
				txtcpf.setText("");
				txtano.setText("");
				txtemail.setText("");
				txttelefone.setText("");
			}
		});
		btnLimpar.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnLimpar.setBounds(343, 316, 112, 46);
		frame.getContentPane().add(btnLimpar);
		
		btnvoltar = new JButton(" voltar a clientes");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaCliente window = new TelaCliente();
				
				window.frame.setVisible(true);
				
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnvoltar.setBounds(17, 316, 169, 46);
		frame.getContentPane().add(btnvoltar);
		
		btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnmenu.setBounds(483, 316, 152, 46);
		frame.getContentPane().add(btnmenu);
	}

}
