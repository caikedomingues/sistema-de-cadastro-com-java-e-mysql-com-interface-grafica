import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AlterarCliente {

	JFrame frame;
	private JTextField txtcpf;
	private JTextField txtnome;
	private JTextField txtano;
	private JTextField txtemail;
	private JTextField txttelefone;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AlterarCliente window = new AlterarCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AlterarCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 808, 468);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("informe o cpf do cliente e altere os dados");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(191, 26, 401, 34);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblcpf = new JLabel("Cpf:");
		lblcpf.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblcpf.setBounds(72, 74, 45, 22);
		frame.getContentPane().add(lblcpf);
		
		txtcpf = new JTextField();
		txtcpf.setBounds(201, 79, 142, 19);
		frame.getContentPane().add(txtcpf);
		txtcpf.setColumns(10);
		
		JLabel lblnome = new JLabel("Nome:");
		lblnome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnome.setBounds(54, 115, 63, 22);
		frame.getContentPane().add(lblnome);
		
		txtnome = new JTextField();
		txtnome.setColumns(10);
		txtnome.setBounds(202, 120, 141, 19);
		frame.getContentPane().add(txtnome);
		
		JLabel lblano = new JLabel("Ano de nascimento:");
		lblano.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblano.setBounds(30, 161, 161, 22);
		frame.getContentPane().add(lblano);
		
		txtano = new JTextField();
		txtano.setBounds(201, 166, 142, 19);
		frame.getContentPane().add(txtano);
		txtano.setColumns(10);
		
		JLabel lblemail = new JLabel("Email:");
		lblemail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblemail.setBounds(54, 204, 63, 22);
		frame.getContentPane().add(lblemail);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBounds(201, 209, 142, 19);
		frame.getContentPane().add(txtemail);
		
		JLabel lbltelefone = new JLabel("Telefone:");
		lbltelefone.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lbltelefone.setBounds(44, 245, 87, 22);
		frame.getContentPane().add(lbltelefone);
		
		txttelefone = new JTextField();
		txttelefone.setColumns(10);
		txttelefone.setBounds(201, 250, 142, 19);
		frame.getContentPane().add(txttelefone);
		
		JButton btnalterar = new JButton("Alterar dados");
		btnalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexaoBanco banco = new ConexaoBanco();
				
				if(txtcpf.getText().length() > 6 || txtcpf.getText().length() < 6) {
					
					JOptionPane.showMessageDialog(null, "O cpf deve conter apenas 6 digitos");
				}
				
				if(txttelefone.getText().length() > 11 || txttelefone.getText().length() < 11) {
					
					JOptionPane.showMessageDialog(null, "O telefone deve conter apenas 11 digitos");
				}
				
				banco.conexao();
				banco.alterarCliente(txtcpf.getText(), txtnome.getText(), txtano.getText(), txtemail.getText(), txttelefone.getText());
				banco.desconectar();
			}
		});
		btnalterar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnalterar.setBounds(230, 336, 142, 43);
		frame.getContentPane().add(btnalterar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtcpf.setText("");
				txtnome.setText("");
				txtano.setText("");
				txtemail.setText("");
				txttelefone.setText("");
			}
		});
		btnLimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLimpar.setBounds(390, 336, 142, 43);
		frame.getContentPane().add(btnLimpar);
		
		JButton btnvoltar = new JButton("Voltar a clientes");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaCliente window = new TelaCliente();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(44, 336, 170, 43);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(561, 336, 170, 43);
		frame.getContentPane().add(btnmenu);
	}

}
