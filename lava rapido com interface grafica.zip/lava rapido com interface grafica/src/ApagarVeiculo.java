import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ApagarVeiculo {

	JFrame frame;
	private JTextField txtplaca;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApagarVeiculo window = new ApagarVeiculo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ApagarVeiculo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 801, 477);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Informe a placa do veiculo que vai ser excluido");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(160, 40, 462, 32);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblplaca = new JLabel("Placa:");
		lblplaca.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblplaca.setBounds(160, 109, 101, 22);
		frame.getContentPane().add(lblplaca);
		
		txtplaca = new JTextField();
		txtplaca.setBounds(227, 114, 149, 19);
		frame.getContentPane().add(txtplaca);
		txtplaca.setColumns(10);
		
		JButton btnapagar = new JButton("Apagar");
		btnapagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexaoBanco banco = new ConexaoBanco();
				
				if(txtplaca.getText().length() > 4 || txtplaca.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A placa deve conter apenas 4 digitos");
				}
				
				banco.conexao();
				banco.apagarVeiculo(txtplaca.getText());
				banco.desconectar();
			}
		});
		btnapagar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnapagar.setBounds(265, 196, 101, 40);
		frame.getContentPane().add(btnapagar);
		
		JButton btnvoltar = new JButton("Voltar a Veiculos");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaVeiculos window = new TelaVeiculos();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(38, 196, 188, 40);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtplaca.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(413, 196, 101, 40);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(561, 196, 156, 40);
		frame.getContentPane().add(btnmenu);
	}

}
