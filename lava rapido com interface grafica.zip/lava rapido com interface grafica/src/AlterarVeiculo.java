import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AlterarVeiculo {

	JFrame frame;
	private JTextField txtplaca;
	private JTextField txtmodelo;
	private JTextField txtcor;
	private JTextField txtservico;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AlterarVeiculo window = new AlterarVeiculo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AlterarVeiculo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 749, 497);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Informe a placa do veiculo que terá os dados atualizados");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(124, 44, 517, 36);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblplaca = new JLabel("Placa:");
		lblplaca.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblplaca.setBounds(131, 110, 75, 30);
		frame.getContentPane().add(lblplaca);
		
		txtplaca = new JTextField();
		txtplaca.setBounds(189, 119, 146, 19);
		frame.getContentPane().add(txtplaca);
		txtplaca.setColumns(10);
		
		JLabel lblmodelo = new JLabel("Modelo:");
		lblmodelo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblmodelo.setBounds(111, 162, 75, 30);
		frame.getContentPane().add(lblmodelo);
		
		txtmodelo = new JTextField();
		txtmodelo.setColumns(10);
		txtmodelo.setBounds(189, 171, 146, 19);
		frame.getContentPane().add(txtmodelo);
		
		JLabel lblcor = new JLabel("Cor:");
		lblcor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblcor.setBounds(131, 212, 75, 30);
		frame.getContentPane().add(lblcor);
		
		txtcor = new JTextField();
		txtcor.setColumns(10);
		txtcor.setBounds(189, 221, 146, 19);
		frame.getContentPane().add(txtcor);
		
		JLabel lblservico = new JLabel("Serviço:");
		lblservico.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblservico.setBounds(111, 252, 75, 30);
		frame.getContentPane().add(lblservico);
		
		txtservico = new JTextField();
		txtservico.setColumns(10);
		txtservico.setBounds(189, 261, 146, 19);
		frame.getContentPane().add(txtservico);
		
		JButton btnalterar = new JButton("Alterar");
		btnalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexaoBanco banco = new ConexaoBanco();
				
				banco.conexao();
				banco.alterarVeiculo(txtplaca.getText(), txtmodelo.getText(), txtcor.getText(), txtservico.getText());
				banco.desconectar();
			}
		});
		btnalterar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnalterar.setBounds(264, 342, 116, 36);
		frame.getContentPane().add(btnalterar);
		
		JButton btnvoltar = new JButton("Voltar a Veiculos");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaVeiculos window = new TelaVeiculos();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(54, 342, 173, 36);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtplaca.setText("");
				txtmodelo.setText("");
				txtcor.setText("");
				txtservico.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(409, 342, 116, 36);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(555, 342, 170, 36);
		frame.getContentPane().add(btnmenu);
	}

}
