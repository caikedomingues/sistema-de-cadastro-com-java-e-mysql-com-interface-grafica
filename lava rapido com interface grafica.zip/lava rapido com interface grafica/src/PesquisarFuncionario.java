import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PesquisarFuncionario {

	JFrame frame;
	private JTextField txtid;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PesquisarFuncionario window = new PesquisarFuncionario();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PesquisarFuncionario() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 852, 404);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Informe o id do funcionário que será pesquisado");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(201, 29, 447, 31);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblid = new JLabel("ID:");
		lblid.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblid.setBounds(188, 106, 45, 13);
		frame.getContentPane().add(lblid);
		
		txtid = new JTextField();
		txtid.setBounds(231, 106, 143, 19);
		frame.getContentPane().add(txtid);
		txtid.setColumns(10);
		
		JButton btnpesquisar = new JButton("Pesquisar");
		btnpesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int id = Integer.parseInt(txtid.getText());
				
				ConexaoBanco banco = new ConexaoBanco();
				
				banco.conexao();
				banco.pesquisarFuncionario(id);
				banco.desconectar();
				
			}
		});
		btnpesquisar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnpesquisar.setBounds(265, 187, 136, 48);
		frame.getContentPane().add(btnpesquisar);
		
		JButton btnvoltar = new JButton("Voltar a Funcionarios");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaFuncionario window = new TelaFuncionario();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(38, 187, 206, 48);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtid.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(429, 187, 136, 48);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(596, 187, 161, 48);
		frame.getContentPane().add(btnmenu);
	}

}
