import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PesquisarCliente {

	JFrame frame;
	private JTextField txtcpf;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PesquisarCliente window = new PesquisarCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PesquisarCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 686, 315);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Digite o cpf do cliente ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(173, 45, 191, 28);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblcpf = new JLabel("CPF");
		lblcpf.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblcpf.setBounds(173, 112, 66, 20);
		frame.getContentPane().add(lblcpf);
		
		txtcpf = new JTextField();
		txtcpf.setBounds(228, 115, 104, 19);
		frame.getContentPane().add(txtcpf);
		txtcpf.setColumns(10);
		
		JButton btnNewButton = new JButton("Pesquisar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ConexaoBanco banco = new ConexaoBanco();
				
				banco.conexao();
				banco.pesquisarCliente(txtcpf.getText());
				banco.desconectar();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(236, 174, 104, 43);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtcpf.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnlimpar.setBounds(363, 174, 104, 43);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("voltar a clientes");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaCliente window = new TelaCliente();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnvoltar.setBounds(76, 174, 150, 43);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnmenu.setBounds(482, 174, 143, 43);
		frame.getContentPane().add(btnmenu);
	}

}
