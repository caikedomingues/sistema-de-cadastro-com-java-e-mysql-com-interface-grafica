import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaCliente {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaCliente window = new TelaCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 945, 554);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btncadastrocliente = new JButton("cadastre um cliente");
		btncadastrocliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CadastroCliente window = new CadastroCliente();
				
				window.frame.setVisible(true);
				
			}
		});
		btncadastrocliente.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btncadastrocliente.setBounds(308, 117, 213, 52);
		frame.getContentPane().add(btncadastrocliente);
		
		JButton btnPesquisar = new JButton("pesquise um cliente");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PesquisarCliente window = new PesquisarCliente();
				
				window.frame.setVisible(true);
			}
		});
		btnPesquisar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnPesquisar.setBounds(308, 206, 213, 52);
		frame.getContentPane().add(btnPesquisar);
		
		JButton btnalterar = new JButton("altere um cliente");
		btnalterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AlterarCliente window = new AlterarCliente();
				
				window.frame.setVisible(true);
			}
		});
		btnalterar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnalterar.setBounds(308, 291, 213, 52);
		frame.getContentPane().add(btnalterar);
		
		JButton btnapagar = new JButton("apague um cliente");
		btnapagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ApagarCliente window = new ApagarCliente();
				
				window.frame.setVisible(true);
			}
		});
		btnapagar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnapagar.setBounds(308, 367, 213, 52);
		frame.getContentPane().add(btnapagar);
		
		JButton btnmenu = new JButton("Menu Principal");
		btnmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnmenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnmenu.setBounds(308, 443, 213, 52);
		frame.getContentPane().add(btnmenu);
	}

}
