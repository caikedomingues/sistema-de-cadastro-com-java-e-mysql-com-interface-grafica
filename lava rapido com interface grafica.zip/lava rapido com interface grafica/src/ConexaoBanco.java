
import javax.swing.JOptionPane;

import java.sql.DriverManager;

import java.sql.ResultSet;

import java.sql.Statement;

import java.sql.Connection;

import java.sql.SQLException;


public class ConexaoBanco {
	
	Connection con = null;
	   
	Statement state = null;
	
	ResultSet res = null;

    public void conexao() {
	   
    	try {
    		
    		String link = "jdbc:mysql://localhost:3306/lavarapido?user=root&password=";
        	
        	con = DriverManager.getConnection(link);
        	
        	this.state = this.con.createStatement();
        	
        	JOptionPane.showMessageDialog(null, "Bem vindo ao banco de dados");
        	
        	
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null,"Não foi possivel conectar o banco de dados: " + erro);
    	}
	  
	   
   }
    
    
    public void inserirCliente(String nome, String cpf, String anoNasc, String email, String telefone) {
    	
    	try {
    		
    		String query = "insert into clientes (nome, cpf, anoNasc, email, telefone) values('"+ nome +"', '"+ cpf +"', '"+ anoNasc +"', '"+ email +"', '"+ telefone +"');";
    		
    		System.out.println(query);
    		
    		this.state.executeUpdate(query);
    		
    		JOptionPane.showMessageDialog(null, "Cliente inserido com sucesso");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel inserir o cliente " + erro);
    	}
    	
    }
    
    public void pesquisarCliente(String cpf) {
    	
    	try {
    		
    		String query = "select * from clientes where cpf = '"+ cpf +"';";
    		
    		this.res = this.state.executeQuery(query);
    		
    		while(res.next()) {
    			
    			JOptionPane.showMessageDialog(null, "Nome: " + res.getString("nome") + " | cpf: " + res.getString("cpf") + " | ano de nascimento: " + res.getString("anoNasc") + " | email: " + res.getString("email") + " | telefone: " + res.getString("telefone"));
    		}
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel pesquisar: " + erro);
    	}
    }
    
    public void alterarCliente(String cpf, String nome, String anoNasc, String email, String telefone) {
    	
    	try {
    		
    		String query = "update clientes set nome = '"+ nome +"' where cpf = '"+ cpf +"';";
    		
    		String query2 = "update clientes set anoNasc = '"+ anoNasc +"' where cpf = '"+ cpf +"';";
    		
    		String query3 = "update clientes set email = '"+ email +"' where cpf = '"+ cpf +"';";
    		
    		String query4 = "update clientes set telefone = '"+ telefone +"' where cpf = '"+ cpf +"';";
    		
    		this.state.executeUpdate(query);
    		
    		this.state.executeUpdate(query2);
    		
    		this.state.executeUpdate(query3);
    		
    		this.state.executeUpdate(query4);
    		
    		JOptionPane.showMessageDialog(null, "Dados alterados com sucesso");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel alterar os dados: " + erro);
    	}
    }
    
    public void apagarCliente(String cpf) {
    	
    	try {
    		
    		String query = "delete from clientes where cpf = '"+ cpf +"';"; 
    		
    		this.state.executeUpdate(query);
    		
    		JOptionPane.showMessageDialog(null, "Cliente excluido com sucesso");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel excluir o cliente: " + erro);
    		
    	}
    }
    
    
    public void cadastrarFuncionario(String nome, String funcao, String setor, int salario) {
    	
    	try {
    		
    		String query = "insert into funcionarios(nome, funcao, setor, salario) values ('"+ nome +"', '"+ funcao +"', '"+ setor +"', '"+ salario +"');";
    		
    		System.out.println(query);
    		
    		this.state.executeUpdate(query);
    		
    		JOptionPane.showMessageDialog(null, "Funcionario cadastrado com sucesso ");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel cadastrar o funcionário: " + erro);
    		
    	}
    	
    	
    }
    
    public void pesquisarFuncionario(int id) {
    	
    	try {
    		
    		String query = "select * from funcionarios where id = '"+ id +"'";
    		
    		this.res = this.state.executeQuery(query);
    		
    		while(this.res.next()) {
    			
    			JOptionPane.showMessageDialog(null, "Nome: " + this.res.getString("nome") + " | id: " + this.res.getInt("id") + " | função: " + this.res.getString("funcao") + " | setor: " + this.res.getString("setor") + " | salario: " + this.res.getInt("salario"));
    		}
    		
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel encontrar o funcionário: " + erro);
    		
    	}
    }
    
    public void alterarFuncionario(int id, String nome, String funcao, String setor, int salario) {
    	
    	try {
    		
    		String query = "update funcionarios set nome = '"+ nome +"' where id = '"+ id +"';";
    		
    		String query2 = "update funcionarios set funcao = '"+ funcao +"' where id = '"+ id +"';";
    		
    		String query3 = "update funcionarios set setor = '"+ setor +"' where id = '"+ id +"';";
    		
    		String query4 = "update funcionarios set salario = '"+ salario +"' where id = '"+ id +"'";
    		
    		this.state.executeUpdate(query);
    		
    		this.state.executeUpdate(query2);
    		
    		this.state.executeUpdate(query3);
    		
    		this.state.executeUpdate(query4);
    		
    		JOptionPane.showMessageDialog(null, "Dados alterados com sucesso");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null,"Não foi possivel alterar os dados: " + erro);
    		
    	}
    }
    
    
    public void apagarFuncionario(int id) {
    	
    	try {
    		
    		String query = "delete from funcionarios where id = '"+ id +"';";
    		
    		this.state.executeUpdate(query);
    		
    		JOptionPane.showMessageDialog(null, "Funcionário excluido com sucesso");
    		
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel excluir o funcionário: " + erro);
    		
    	}
    }
    
    public void cadastrarVeiculo(String modelo, String cor, String placa, String servico) {
    	
    	try {
    		
    		String query = "insert into veiculos(modelo, cor, placa, servico) values('"+ modelo +"', '"+ cor +"', '"+ placa +"', '"+ servico +"');";
    		
    		System.out.println(query);
    		
    		this.state.executeUpdate(query);
    		
    		JOptionPane.showMessageDialog(null, "Veiculo cadastrado com sucesso ");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel cadastrar o veiculo: " + erro);
    		
    		
    	}
    }
    
    
    public void pesquisarVeiculo(String placa) {
    	
    	try {
    		
    		String query = "select * from veiculos where placa = '"+ placa +"';";
    		
    		this.res = this.state.executeQuery(query);
    		
    		while(this.res.next()) {
    			
    			JOptionPane.showMessageDialog(null, "Modelo: " + this.res.getString("modelo") + " | cor: " + this.res.getString("cor") + " | placa: " + this.res.getString("placa") + " | serviço: " + this.res.getString("servico"));
    		}
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel encontrar o veiculo: " + erro);
    		
    	}
    	
    }
    
    public void alterarVeiculo(String placa, String modelo, String cor, String servico) {
    	
    	try {
    		
    		String query = "update veiculos set modelo = '"+ modelo +"' where placa = '"+ placa +"';";
    		String query2 = "update veiculos set cor = '"+ cor +"' where placa = '"+ placa +"';";
    		String query3 = "update veiculos set servico = '"+ servico +"' where placa = '"+ placa +"';";
    		
    		this.state.executeUpdate(query);
    		this.state.executeUpdate(query2);
    		this.state.executeUpdate(query3);
    		
    		JOptionPane.showMessageDialog(null, "dados alterados com sucesso");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel atualizar os dados do veiculo: " + erro);
    	}
    }
    
    public void apagarVeiculo(String placa) {
    	
    	try {
    		
    		String query = "delete from veiculos where placa = '"+ placa +"';";
    		
    		this.state.executeUpdate(query);
    		
    		JOptionPane.showMessageDialog(null, "Veiculo excluido com sucesso");
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "Não foi possivel excluir o veiculo " + erro);
    		
    		
    	}
    }
    
    
    public void desconectar() {
    	
    	try {
    		
    		this.con.close();
    		
    	}catch(SQLException | NullPointerException erro) {
    		
    		JOptionPane.showMessageDialog(null, "não foi possivel desconectar " + erro);
    	}
    }
	

}
